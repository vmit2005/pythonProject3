from controler import Controller
from viev import UserInterface

def main():
    app=Controller()
    app.run()


if __name__=='__main__':
    main()
