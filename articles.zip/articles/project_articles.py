from controller import Controller
from view import UserInterface

def main():
    app=Controller()
    app.run()


if __name__=='__main__':
    main()