from ramка import Ramка, add_ramka

@add_ramka(20,'Проба РАМКИ',"Cnhjrf 2")
def proverka():
    print("Ghjdthrf")

proverka()